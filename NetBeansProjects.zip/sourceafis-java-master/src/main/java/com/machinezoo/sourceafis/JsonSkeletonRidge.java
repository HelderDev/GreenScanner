// Part of SourceAFIS: https://sourceafis.machinezoo.com
package com.machinezoo.sourceafis;

class JsonSkeletonRidge {
	int start;
	int end;
	int length;
}
