// Part of SourceAFIS: https://sourceafis.machinezoo.com
package com.machinezoo.sourceafis;

enum ForeignFormat {
	ANSI_378_2004,
	ANSI_378_2009,
	ANSI_378_2009_AM1,
	ISO_19794_2_2005;
}
