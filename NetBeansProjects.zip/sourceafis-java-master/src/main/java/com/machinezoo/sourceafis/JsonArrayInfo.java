// Part of SourceAFIS: https://sourceafis.machinezoo.com
package com.machinezoo.sourceafis;

class JsonArrayInfo {
	String[] axes;
	int[] dimensions;
	String scalar;
	int bitness;
	String endianness;
	String format;
}