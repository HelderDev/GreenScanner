// Part of SourceAFIS: https://sourceafis.machinezoo.com
package com.machinezoo.sourceafis;

class JsonBestMatch {
	int offset;
	JsonBestMatch(int offset) {
		this.offset = offset;
	}
}